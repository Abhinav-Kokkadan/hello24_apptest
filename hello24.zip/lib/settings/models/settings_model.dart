// lib/settings/models/settings_model.dart
import 'package:flutter/foundation.dart';


class SettingsModel extends ChangeNotifier {
  String language = 'English';
  List<String> phoneNumbers = [];
  List<String> inUseStars = [];
  List<String> notInUseStars = [];
  String signature = '';

// ... Add methods to update settings and notify listeners
}
