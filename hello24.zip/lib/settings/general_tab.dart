// lib/settings/general_tab.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:untitled1/settings/widgets/custom_widgets.dart';

import '../models/settings_model.dart';
import '../widgets/custom_widgets.dart';
import 'models/settings_model.dart';

class GeneralTab extends StatelessWidget {
  const GeneralTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsModel>();

    return Scaffold(
      appBar: AppBar(
        title: Text('General'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Language & Phone Numbers section
            LanguageAndPhoneNumbersSection(),
            // Default Text section
            DefaultTextSection(),
            // Stars section
            StarsSection(),
            // Signature section
            SignatureSection(),
          ],
        ),
      ),
    );
  }
}
