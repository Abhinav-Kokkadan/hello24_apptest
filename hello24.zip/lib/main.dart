// lib/main.dart
import 'package:flutter/material.dart';
import 'settings/models/settings_model.dart';
import 'settings/general_tab.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => SettingsModel(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 1,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Settings'),
            bottom: TabBar(
              tabs: [
                Tab(icon: Icon(Icons.settings), text: 'General'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              GeneralTab(),
            ],
          ),
        ),
      ),
    );
  }
}

